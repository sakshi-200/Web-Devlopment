#! C:/Program Files/Python39/Python
import cgi
import mysql.connector as mycon

print("Content-type: text/html")
print()

con=mycon.connector.connect(host='localhost',user='root',password='APPLE',database='userdb')
curs=con.cursor()

form=cgi.FieldStorage()
custid=form.getvalue("id")

curs.execute("select * from customers where custid='%s'" %(id))
rec=curs.fetchone()

if rec:
    #print("<h2>Welcome %s to serverside python</h2>" %id)
    print("<html>")
    print("<head>")
    print("<meta http-equiv='refresh' content='0;url=Home.html'/>")
    print("</head>")
    print("</html>")
else:
    print("<h2>Sorry authentication failed</h2>")

con.close()