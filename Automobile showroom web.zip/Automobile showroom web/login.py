#! C:/Program Files/Python39/Python
import cgi 
import mysql.connector 

print("Content-type: text/html")
print()

con=mysql.connector.connect(host='localhost',user='root',password='APPLE',database='userdb')
curs=con.cursor()

form=cgi.FieldStorage()

email=form.getvalue("email")
password=form.getvalue("password")


curs.execute("insert into user values('%s','%s')" %(email,password))
con.commit()

print("<h3>User registration successful</h3>")
print("<a href='Home.html'>Home</a>")

con.close()
